package com.example.deliverable3;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

public class Discovery extends AppCompatActivity {
    private ArrayList<BluetoothDevice> deviceList;
    Button Botoncerrar;
    Button BotonStartDis;
    private static final int REQUEST_BLUETOOTH_SCAN = 1002;
    private static final int REQUEST_ALL_BT_PERMISSIONS = 1003;
    BroadcastReceiver discoveryResult;
    private BluetoothAdapter bluetooth;
    private ArrayAdapter<String> deviceAdapter;
    private ListView deviceListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.discovery);

        deviceList = new ArrayList<>();
        Botoncerrar = findViewById(R.id.closeButton);
        BotonStartDis = findViewById(R.id.startDiscovery);
        bluetooth = BluetoothAdapter.getDefaultAdapter();
        deviceListView = findViewById(R.id.devicelistView);
        deviceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        deviceListView.setAdapter(deviceAdapter);

        discoveryResult = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    String remoteDeviceName = intent.getStringExtra(BluetoothDevice.EXTRA_NAME);
                    BluetoothDevice remoteDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    int rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE);

                    if (remoteDevice != null && remoteDeviceName != null && !remoteDeviceName.isEmpty()) {
                        String deviceInfo = remoteDeviceName + " (" + remoteDevice.getAddress() + ")";
                        if (deviceAdapter.getPosition(deviceInfo) == -1) {
                            deviceAdapter.add(deviceInfo);
                            deviceAdapter.notifyDataSetChanged();
                            deviceList.add(remoteDevice);
                        }
                    }

                    Log.d("Discovery", "Discovered " + remoteDeviceName + " RSSI=" + rssi + " dBm");
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                    BotonStartDis.setText("Start Discovery");
                    Toast.makeText(context, "Discovery finished", Toast.LENGTH_SHORT).show();
                }
            }
        };

        deviceListView.setOnItemClickListener((parent, view, position, id) -> {
            BluetoothDevice selectedDevice = deviceList.get(position);
            Toast.makeText(this, "Conectando a " + selectedDevice.getName(), Toast.LENGTH_SHORT).show();

            boolean connected = BluetoothService.getInstance().connect(selectedDevice);
            if (connected) {
                Intent result = new Intent();
                result.putExtra("DEVICE_ADDRESS", selectedDevice.getAddress());
                setResult(Activity.RESULT_OK, result);
                Toast.makeText(this, "Conectado a " + selectedDevice.getName(), Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error al conectar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_BLUETOOTH_SCAN) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Bluetooth Discovery ENABLED", Toast.LENGTH_LONG).show();
                startDiscovery();
            } else {
                Toast.makeText(this, "Permiso BLUETOOTH SCAN denegado", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startDiscovery(){
        if (!hasDiscoveryPermission()){
            requestDiscoveryPermission();
            return;
        }
        deviceList.clear();
        deviceAdapter.clear();
        deviceAdapter.notifyDataSetChanged();

        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(discoveryResult, filter);

        if (bluetooth.isDiscovering()) {
            bluetooth.cancelDiscovery();
        }

        Log.d("DEBUG", "BluetoothAdapter: " + bluetooth);
        Log.d("DEBUG", "isEnabled: " + bluetooth.isEnabled());
        Log.d("DEBUG", "isDiscovering: " + bluetooth.isDiscovering());
        Log.d("DEBUG", "Scan Mode: " + bluetooth.getScanMode());

        boolean ok = bluetooth.startDiscovery();
        Log.d("DEBUG", "startDiscovery result: " + ok);
        if(!ok){
            Toast.makeText(this, "Could not start discovery", Toast.LENGTH_SHORT).show();
        }
        else {
            BotonStartDis.setText("Discovering...");
        }
    }

    private boolean hasDiscoveryPermission(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestDiscoveryPermission(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.BLUETOOTH_SCAN,
                            Manifest.permission.BLUETOOTH_CONNECT,
                            Manifest.permission.ACCESS_FINE_LOCATION
                    },
                    REQUEST_ALL_BT_PERMISSIONS
            );
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_ALL_BT_PERMISSIONS
            );
        }
    }

    public void onClickClose(View view) {
        finish();
    }

    public void onClickStart(View view){
        startDiscovery();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(discoveryResult);
        } catch (Exception ignored) {}
    }
}
