package com.example.deliverable3;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private static final int REQUEST_CAMERA_PERMISSION = 1001;
    private static final int REQUEST_BLUETOOTH_CONNECT = 2001;

    private String poseServerBaseUrl = null;
    private String poseServerStreamUrl = null;
    private String poseServerUploadUrl = null;
    private String landmarksUrl = null;

    private static final long PREVIEW_UPLOAD_INTERVAL_MS = 150;

    private FrameLayout cameraPreviewFrameLayout;
    private CameraPreview mCameraPreview;
    private android.hardware.Camera mCamera;

    private WebView robotStreamView;
    private TextView webText;
    private TextView statusLabel;

    private BluetoothAdapter bluetooth;
    private ActivityResultLauncher<Intent> enableBtLauncher;
    private ActivityResultLauncher<Intent> serverDiscoveryLauncher;

    public static Boolean bluetoothActive = false;

    public Handler handlerNetworkExecutorResult;
    private NetworkExecutor networkExecutor;

    private final Handler visionPollHandler = new Handler(Looper.getMainLooper());
    private final Runnable visionPollRunnable = new Runnable() {
        @Override
        public void run() {
            fetchLandmarks();
            visionPollHandler.postDelayed(this, 700);
        }
    };

    private String lastLandmarksText = "Sin landmarks todavía";
    private boolean hasUploadedAtLeastOneFrame = false;

    private volatile boolean uploadInProgress = false;
    private long lastPreviewUploadMs = 0L;
    private boolean previewStreamingEnabled = true;
    private boolean serverDiscoveryOpen = false;

    private boolean pendingStartProcessedStream = false;
    private boolean processedStreamLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        cameraPreviewFrameLayout = findViewById(R.id.cameraView);
        webText = findViewById(R.id.webText);
        statusLabel = null;

        refreshInfoText();

        serverDiscoveryLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    serverDiscoveryOpen = false;

                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        String ip = result.getData().getStringExtra("SERVER_IP");
                        if (ip != null && !ip.isEmpty()) {
                            setServerIp(ip);
                            refreshInfoText();

                            pendingStartProcessedStream = true;
                            processedStreamLoaded = false;
                            showProcessedOverlay(false);
                        }
                    } else {
                        toast("No se seleccionó ningún servidor");
                        showProcessedOverlay(false);
                    }
                }
        );

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA_PERMISSION
            );
        } else {
            startCameraPreview();
        }

        View root = findViewById(R.id.main);
        if (root != null) {
            ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        handlerNetworkExecutorResult = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                Object obj = msg.obj;
                if (!(obj instanceof String)) return;

                String cmd = (String) obj;
                Log.d(TAG, "Cmd: " + cmd);

                switch (cmd) {
                    case "FORWARD":
                        forward();
                        status("Forward (HTTP)");
                        break;
                    case "BACKWARD":
                        backward();
                        status("Backward (HTTP)");
                        break;
                    case "LEFT":
                        left();
                        status("Left (HTTP)");
                        break;
                    case "RIGHT":
                        right();
                        status("Right (HTTP)");
                        break;
                    case "TURNLEFT":
                        turnLeft();
                        status("Turn left (HTTP)");
                        break;
                    case "TURNRIGHT":
                        turnRight();
                        status("Turn right (HTTP)");
                        break;
                    case "SPEEDUP":
                        speedUp();
                        status("Speed + (HTTP)");
                        break;
                    case "SPEEDDOWN":
                        speedDown();
                        status("Speed - (HTTP)");
                        break;
                    case "CAMERA":
                        forceSinglePreviewUpload();
                        status("Capture + process");
                        break;
                    case "STOP":
                        stop();
                        status("Stop (HTTP)");
                        break;
                    default:
                        if (cmd.startsWith("MSG:")) {
                            String text = cmd.substring(4);
                            toast("Mensaje web: " + text);
                            status("MSG: " + text);
                        }
                        break;
                }
            }
        };

        networkExecutor = new NetworkExecutor(this, handlerNetworkExecutorResult);
        networkExecutor.start();

        bluetooth = BluetoothAdapter.getDefaultAdapter();
        if (bluetooth == null) {
            toast("Este dispositivo no soporta Bluetooth");
        }

        enableBtLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        bluetoothActive = true;
                        status("Bluetooth ENABLED");
                    } else {
                        bluetoothActive = false;
                        status("Usuario canceló activar Bluetooth");
                    }
                }
        );

        openServerDiscovery();
    }

    private void setServerIp(String ip) {
        poseServerBaseUrl = "http://" + ip + ":8090";
        poseServerStreamUrl = poseServerBaseUrl + "/stream.mjpg";
        poseServerUploadUrl = poseServerBaseUrl + "/upload_frame";
        landmarksUrl = poseServerBaseUrl + "/landmarks";

        resetVisionConnectionState();
        pendingStartProcessedStream = true;
        processedStreamLoaded = false;
        showProcessedOverlay(false);

        Log.d(TAG, "Servidor configurado dinámicamente: " + poseServerBaseUrl);
    }

    private boolean hasServerConfigured() {
        return poseServerBaseUrl != null
                && poseServerStreamUrl != null
                && poseServerUploadUrl != null
                && landmarksUrl != null;
    }

    private void openServerDiscovery() {
        if (serverDiscoveryOpen) return;
        serverDiscoveryOpen = true;

        Intent intent = new Intent(MainActivity.this, ServerDiscoveryActivity.class);
        serverDiscoveryLauncher.launch(intent);
    }

    public void onClickFindServer(View view) {
        openServerDiscovery();
    }

    private void ensureProcessedOverlay() {
        if (robotStreamView != null) return;

        robotStreamView = new WebView(this);
        WebSettings settings = robotStreamView.getSettings();
        settings.setJavaScriptEnabled(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        robotStreamView.setVerticalScrollBarEnabled(false);
        robotStreamView.setHorizontalScrollBarEnabled(false);
        robotStreamView.setBackgroundColor(Color.TRANSPARENT);

        robotStreamView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                showProcessedOverlay(true);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                showProcessedOverlay(false);
            }
        });

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        robotStreamView.setLayoutParams(params);
        robotStreamView.setVisibility(View.INVISIBLE);

        cameraPreviewFrameLayout.addView(robotStreamView);
    }

    private void showProcessedOverlay(boolean show) {
        if (robotStreamView == null) return;

        if (show) {
            robotStreamView.setVisibility(View.VISIBLE);
            robotStreamView.bringToFront();
        } else {
            robotStreamView.setVisibility(View.INVISIBLE);
        }
    }

    private void startCameraPreview() {
        if (mCamera == null) {
            mCamera = getCameraInstance();
        }
        if (mCamera == null) {
            Log.e(TAG, "No se pudo obtener la cámara");
            return;
        }

        cameraPreviewFrameLayout.removeAllViews();

        mCameraPreview = new CameraPreview(this, mCamera);
        mCameraPreview.setPreviewFrameListener(this::onPreviewFrameAvailable);
        cameraPreviewFrameLayout.addView(mCameraPreview);

        ensureProcessedOverlay();
    }

    private void onPreviewFrameAvailable(byte[] data, android.hardware.Camera camera) {
        if (!previewStreamingEnabled) return;
        if (uploadInProgress) return;

        long now = System.currentTimeMillis();
        if (now - lastPreviewUploadMs < PREVIEW_UPLOAD_INTERVAL_MS) return;

        try {
            android.hardware.Camera.Size size = camera.getParameters().getPreviewSize();
            if (size == null) return;

            byte[] jpegBytes = nv21ToJpeg(data, size.width, size.height, 55);
            if (jpegBytes == null) return;

            byte[] rotatedJpegBytes = rotateJpeg90(jpegBytes);
            if (rotatedJpegBytes == null) return;

            lastPreviewUploadMs = now;
            uploadPreviewFrame(rotatedJpegBytes);
        } catch (Exception e) {
            Log.e(TAG, "Error procesando preview frame", e);
        }
    }

    private byte[] rotateJpeg90(byte[] jpegBytes) {
        try {
            Bitmap originalBitmap = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.length);
            if (originalBitmap == null) return null;

            Matrix matrix = new Matrix();
            matrix.postRotate(90);

            Bitmap rotatedBitmap = Bitmap.createBitmap(
                    originalBitmap,
                    0,
                    0,
                    originalBitmap.getWidth(),
                    originalBitmap.getHeight(),
                    matrix,
                    true
            );

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 55, out);

            return out.toByteArray();
        } catch (Exception e) {
            Log.e(TAG, "rotateJpeg90 failed", e);
            return null;
        }
    }

    private byte[] nv21ToJpeg(byte[] nv21, int width, int height, int quality) {
        try {
            YuvImage yuvImage = new YuvImage(nv21, ImageFormat.NV21, width, height, null);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            boolean ok = yuvImage.compressToJpeg(new Rect(0, 0, width, height), quality, out);
            if (!ok) return null;
            return out.toByteArray();
        } catch (Exception e) {
            Log.e(TAG, "nv21ToJpeg failed", e);
            return null;
        }
    }

    private void uploadPreviewFrame(byte[] imageBytes) {
        if (!hasServerConfigured()) return;

        uploadInProgress = true;

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(poseServerUploadUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(6000);
                conn.setRequestProperty("Content-Type", "image/jpeg");
                conn.setFixedLengthStreamingMode(imageBytes.length);

                OutputStream os = conn.getOutputStream();
                os.write(imageBytes);
                os.flush();
                os.close();

                int code = conn.getResponseCode();
                Log.d(TAG, "uploadPreviewFrame() HTTP code=" + code);

                if (code == 200) {
                    hasUploadedAtLeastOneFrame = true;

                    runOnUiThread(() -> {
                        if (!processedStreamLoaded || robotStreamView == null || robotStreamView.getVisibility() != View.VISIBLE) {
                            startProcessedStream();
                        } else {
                            showProcessedOverlay(true);
                        }
                    });
                }

            } catch (Exception e) {
                Log.e(TAG, "Error subiendo preview al servidor de pose", e);
                runOnUiThread(() -> {
                    showProcessedOverlay(false);
                    toast("Conexión perdida. Buscando servidor...");
                    poseServerBaseUrl = null;
                    poseServerStreamUrl = null;
                    poseServerUploadUrl = null;
                    landmarksUrl = null;
                    resetVisionConnectionState();
                    refreshInfoText();
                    openServerDiscovery();
                });
            } finally {
                if (conn != null) conn.disconnect();
                uploadInProgress = false;
            }
        }).start();
    }

    private void forceSinglePreviewUpload() {
        if (mCamera == null) return;
        if (!hasServerConfigured()) return;

        lastPreviewUploadMs = 0L;
        uploadInProgress = false;
    }

    private void startProcessedStream() {
        if (robotStreamView == null) return;
        if (!hasServerConfigured()) return;

        String streamUrlWithTs = poseServerStreamUrl + "?t=" + System.currentTimeMillis();

        robotStreamView.bringToFront();
        robotStreamView.clearCache(true);
        robotStreamView.loadUrl(streamUrlWithTs);

        processedStreamLoaded = true;
    }

    private android.hardware.Camera getCameraInstance() {
        android.hardware.Camera camera = null;
        try {
            camera = android.hardware.Camera.open(0);
        } catch (Exception e) {
            Log.d(TAG, "ERROR en getCameraInstance()", e);
        }
        return camera;
    }

    private void refreshInfoText() {
        if (webText == null) return;

        String serverText = (poseServerBaseUrl != null) ? poseServerBaseUrl : "Buscando...";

        String text =
                "Servidor pose PC: " + serverText + "\n" +
                        "Últimos landmarks: " + lastLandmarksText;

        webText.setText(text);
    }

    private void fetchLandmarks() {
        if (!hasUploadedAtLeastOneFrame) return;
        if (!hasServerConfigured()) return;

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(landmarksUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(1500);
                conn.setReadTimeout(1500);

                int code = conn.getResponseCode();
                if (code != 200) return;

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                br.close();

                JSONObject obj = new JSONObject(sb.toString());
                String text = formatLandmarksText(obj);

                runOnUiThread(() -> {
                    lastLandmarksText = text;
                    refreshInfoText();
                });

            } catch (Exception e) {
                Log.e(TAG, "Error leyendo landmarks", e);
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private String formatLandmarksText(JSONObject obj) {
        boolean valid = obj.optBoolean("valid", false);
        if (!valid) return "No detection";

        String thyroid = pointToText(obj, "thyroid");
        String prostate = pointToText(obj, "prostate");
        return "thyroid=" + thyroid + " | prostate=" + prostate;
    }

    private String pointToText(JSONObject obj, String key) {
        JSONObject p = obj.optJSONObject(key);
        if (p == null) return "null";
        double x = p.optDouble("x", Double.NaN);
        double y = p.optDouble("y", Double.NaN);
        return "(" + String.format("%.1f", x) + ", " + String.format("%.1f", y) + ")";
    }

    public void onClickConnectButton(View view) {
        if (bluetooth == null) {
            toast("Este dispositivo no soporta Bluetooth");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        REQUEST_BLUETOOTH_CONNECT
                );
                return;
            }
        }

        if (bluetooth.isEnabled()) {
            String name = bluetooth.getName();
            toast("Bluetooth ENABLED: " + name);
            status("Bluetooth ENABLED " + name);

            Intent intent = new Intent(MainActivity.this, Discovery.class);
            startActivity(intent);

        } else {
            Intent enableBt = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            enableBtLauncher.launch(enableBt);
        }
    }

    public void onClickDisconnectButton(View v) {
        BluetoothService.getInstance().disconnect();
        status("Desconectado");
        toast("Desconectado del dispositivo");
    }

    public void onClickForwardButton(View v) { status("Forward"); forward(); }
    public void onClickBackwardButton(View v) { status("Backward"); backward(); }
    public void onClickLeftButton(View v) { status("Left"); left(); }
    public void onClickRightButton(View v) { status("Right"); right(); }
    public void onClickStopButton(View v) { status("Stop"); stop(); }

    public void onClickIncreaseSpeed(View v) { speedUp(); status("Speed +"); }
    public void onClickDecreaseSpeed(View v) { speedDown(); status("Speed -"); }

    public void onClickTurnLeft(View v) { turnLeft(); status("Turn left"); }
    public void onClickTurnRight(View v) { turnRight(); status("Turn right"); }

    public void forward()  { send("w\n"); }
    public void backward() { send("s\n"); }
    public void left()     { send("q\n"); }
    public void right()    { send("e\n"); }
    public void stop()     { send("0\n"); }

    public void turnLeft()  { send("a\n"); }
    public void turnRight() { send("d\n"); }
    public void speedUp()   { send("2\n"); }
    public void speedDown() { send("1\n"); }

    private void send(String text) {
        try {
            BluetoothService service = BluetoothService.getInstance();
            if (service.isConnected()) {
                service.sendData(text.getBytes());
            } else {
                toast("No hay conexión Bluetooth");
            }
        } catch (Exception e) {
            toast("Error enviando datos: " + e.getMessage());
        }
    }

    private void status(String msg) {
        if (statusLabel != null) statusLabel.setText(msg);
        Log.d(TAG, "STATUS: " + msg);
    }

    private void toast(final String text) {
        runOnUiThread(() ->
                Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show()
        );
    }

    public void captureCamera() {
        forceSinglePreviewUpload();
    }

    public void captureCamera(View view) {
        captureCamera();
    }

    private void resetVisionConnectionState() {
        hasUploadedAtLeastOneFrame = false;
        uploadInProgress = false;
        lastPreviewUploadMs = 0L;
        processedStreamLoaded = false;
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            if (mCamera == null) {
                startCameraPreview();
            }
        }

        refreshInfoText();
        visionPollHandler.post(visionPollRunnable);

        if (hasServerConfigured()) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                forceSinglePreviewUpload();

                if (pendingStartProcessedStream || !processedStreamLoaded) {
                    startProcessedStream();
                    pendingStartProcessedStream = false;
                }
            }, 1200);
        } else {
            showProcessedOverlay(false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        visionPollHandler.removeCallbacks(visionPollRunnable);

        if (mCamera != null) {
            try {
                mCamera.setPreviewCallback(null);
                mCamera.release();
            } catch (Exception e) {
                Log.e(TAG, "Error liberando cámara en onPause", e);
            }
            mCamera = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        visionPollHandler.removeCallbacks(visionPollRunnable);

        if (networkExecutor != null) {
            networkExecutor.stopServer();
        }

        BluetoothService.getInstance().disconnect();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCameraPreview();
            } else {
                toast("Permiso de cámara denegado");
            }
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                requestCode == REQUEST_BLUETOOTH_CONNECT) {
            boolean granted = grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED;

            if (granted) {
                String name = (bluetooth != null) ? bluetooth.getName() : "BT";
                toast("Bluetooth ENABLED: " + name);
                status("Bluetooth ENABLED " + name);
            } else {
                toast("Permiso BLUETOOTH_CONNECT denegado");
                status("Permiso BLUETOOTH_CONNECT denegado");
            }
        }
    }
}